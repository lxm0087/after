<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>������Ϣ��ҳ�б�</title>
<link href="template/images/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<br>
<br>
<br>
<table width="500" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
  <tr> 
    <td height="25"><strong>������Ϣ��ҳ�б���</strong></td>
  </tr>
  <tr> 
    <td height="25" bgcolor="#FFFFFF">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
        <?php
		while($r=$empire->fetch($sql))	//ѭ����ȡ��ѯ��¼
		{
			$titleurl=sys_ReturnBqTitleLink($r);	//��������
		?>
        <tr> 
          <td width="74%" height="25">
			<img src="template/images/arrow.gif" border="0" align="absmiddle">&nbsp;[<a href="<?=$public_r[newsurl]?>e/action/ListInfo.php?classid=<?=$r[classid]?>&amp;ph=1&amp;myarea=<?=$r[myarea]?>"><?=$r[myarea]?></a>] <a href="<?=$titleurl?>" target="_blank"> 
            <?=esub(stripslashes($r[title]),32)?>
            </a></td>
          <td width="26%"><div align="center">
              <?=date('Y-m-d',$r[newstime])?>
            </div></td>
        </tr>
        <?php
		}
		?>
		</table> 
    </td>
  </tr>
  <tr>
    <td height="30" bgcolor="#FFFFFF">
      <div class="epages">
        <?=$listpage?>
      </div></td>
  </tr>
</table>
</body>
</html>