<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>��ʾ<?=$context?>����</title>
</head>
<body>
<br>
<br>
<br>
<table width="500" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
  <tr> 
    <td height="25"><strong>��ʾ����Ϊ���£�</strong></td>
  </tr>
  <tr> 
    <td height="60" bgcolor="#FFFFFF"> <div align="center"><strong><font color="#FF0000" size="5"><?=$context?></font></strong></div></td>
  </tr>
</table>
</body>
</html>