<?php

//php对memcache的操作
//① 实例化Memcache类对象
$mem = new Memcache();

//② 连接memcache服务器
$flag = $mem -> connect('localhost',11211);

//④ 把刚刚设置的key给读取出来
var_dump($mem -> get('week'));//string(7) "Tuesday" 

var_dump($mem -> get('slkd*^&%^5623923uKJ?<>'));//string(4) "abcd" 