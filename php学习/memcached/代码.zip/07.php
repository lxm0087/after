<?php

//php对memcache的操作
//① 实例化Memcache类对象
$mem = new Memcache();

//② 连接memcache服务器
$flag = $mem -> connect('localhost',11211);

//③ 获取存储的各种数据类型的信息
$city = array('liaoning'=>'shenyang','hebei'=>'shijiazhuang','shandong'=>'jinan');
class Person{
    var $name = "jim";
    var $height = 170;
    function run(){
        echo "jim is runing";
    }
}
$per = new Person();
$mem -> set('arr',$city,0);
$mem -> set('dui',$per,0);
$mem -> set('kong',null,0);