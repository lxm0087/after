<?php

//php对memcache的操作
//① 实例化Memcache类对象
$mem = new Memcache();

//② 连接memcache服务器
$flag = $mem -> connect('localhost',11211);

var_dump($flag);//true
